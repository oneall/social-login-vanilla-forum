<?php
// Fix for Vanilla 2.2 new locale file locations,
// library/core/class.locale.php @ 264
include dirname(__FILE__) . "/en-CA/definitions.php";

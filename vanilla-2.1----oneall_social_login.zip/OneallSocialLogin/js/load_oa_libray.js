
(function () {
	var oa = document.createElement('script'); oa.type = 'text/javascript'; 
	oa.async = true; oa.src = '//{OA_SOCIAL_LOGIN_API_SUBDOMAIN}.api.oneall.com/socialize/library.js';
		var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(oa, s);
})();
